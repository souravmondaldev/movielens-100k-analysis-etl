CREATE TABLE IF NOT EXISTS user_table (
    user_id INT PRIMARY KEY,
    age INT,
    gender VARCHAR(10),
    occupation VARCHAR(50),
    zip_code VARCHAR(10)
);
